class Paths{
  //Top level collections.
  static const String users = 'users';
}