package com.example.flutter_instagram;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
