package com.example.firebase_tony_stark;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
